<?php
require("../conexiones/conexion.php");
$admin = $_REQUEST['admin'];
$name = $_REQUEST['name'];
$user = $_REQUEST['user'];
$pass = $_REQUEST['pass'];
$type = $_REQUEST['type'];
$gps = $_REQUEST['gps'];
$Q_admin = "SELECT admin FROM user";
$R_admin = $connection->query($Q_admin);
$row_admin = $R_admin->fetch_assoc();

if(in_array($admin,$row_admin)){
	$Q_user = "INSERT INTO user(admin,name,user,pass,type,gps) VALUES($admin,$name,$user,$pass,$type,$gps)";
	$connection->query($Q_user);
}
else{
	$Q_user = "INSERT INTO user(admin,name,user,pass,type,gps) VALUES($admin,$name,$admin,$pass,'admin',$gps)";
	$connection->query($Q_user);
}







?>